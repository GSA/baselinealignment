javascript:void((function(){andiScript=document.createElement('script');andiScript.setAttribute('src','https://www.dhs.gov/xlibrary/oast/ANDI/andi.js');document.body.appendChild(andiScript)})());  

function badpwd(){
  alert("Your password must include at least one number, one special character, one upper-case character, and at least lower-case character.");
}